export class UserRole {}
