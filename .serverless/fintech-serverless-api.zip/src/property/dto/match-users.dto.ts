/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
export class matchUserDto {
@ApiProperty()
  id: string;
}
